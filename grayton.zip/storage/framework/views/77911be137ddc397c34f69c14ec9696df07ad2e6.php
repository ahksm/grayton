<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['locations' => $locations]]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['locations' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($locations)]); ?>
    <div class="container my-5">
        <div class="row">
            <?php $__currentLoopData = $tariffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tariff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body d-flex align-items-center flex-column">
                            <img src="<?php echo e(asset('storage/' . $tariff['image'])); ?>" alt="alt">
                            <h5 class="card-title mt-3"><?php echo e($tariff['name']); ?></h5>
                            <p class="card-text">Price: $<?php echo e($tariff['price']); ?></p>
                            <div class="card-descr text-center"><?php echo $tariff['descr']; ?></div>
                            <a href="/location/<?php echo e(strtolower($tariff->location->country)); ?>/<?php echo e(strtolower($tariff['name'])); ?>" class="btn btn-primary mt-3">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\Workspace\Laravel\grayton\resources\views/tariffs.blade.php ENDPATH**/ ?>