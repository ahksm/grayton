<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container" style="margin: 100px auto;">
        <div class="row justify-content-between">
            <img class="col-lg-4" src="<?php echo e(asset('storage/' . $tariff['image'])); ?>" alt="alt">
            <div class="col-lg-6">
                <h2 class="text-right"><b><?php echo e($tariff['name'] . ', ' . $tariff->location->country); ?></b></h2>
                <div class="text-justify my-5"><?php echo $tariff['descr']; ?></div>
                <div class="d-flex justify-content-between align-items-center">
                    <form action="/order" method="POST" class="order-submit">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="tariff_id" value="<?php echo e($tariff->id); ?>">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                        <button type="submit" class="input-btn btn" style="border: 1px solid #666; color: #666;">Buy</button>
                    </form>
                    <h4 class="text-right"><b>Price: $<?php echo e($tariff['price']); ?></b></h4>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\Workspace\Laravel\grayton\resources\views/tariff/show.blade.php ENDPATH**/ ?>